$(document).ready(function () {
    setTimeout(() => {
        $('.load').fadeOut();
    }, 1000);
});